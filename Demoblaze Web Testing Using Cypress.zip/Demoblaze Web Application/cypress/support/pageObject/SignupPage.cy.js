class SignupPage {
  visit() {
    cy.visit('https://www.demoblaze.com/');
  }

  clickSignup() {
    cy.xpath('//a[@id="signin2"]').click();
  }

  enterUsername() {
    cy.get('#sign-username').type('Kanav1221');
  }

  enterPassword() {
    cy.get('#sign-password').type('kanav@123');
  }

  clickSignupButton() {
    cy.get('button').contains('Sign up').click();
  }
}

export default SignupPage;
