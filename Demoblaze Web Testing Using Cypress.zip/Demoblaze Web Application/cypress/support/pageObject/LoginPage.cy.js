class LoginPage {
  visit() {
    cy.visit('https://www.demoblaze.com/');
  }

  clickLogin() {
    cy.xpath('//a[@id="login2"]').click();
  }

  enterUsername() {
    cy.get('#loginusername').type('Kanav1221');
  }

  enterPassword() {
    cy.get('#loginpassword').type('kanav@123');
  }

  clickLoginButton() {
    cy.get('button').contains('Log in').click();
  }
}

export default LoginPage;
