class CartPage {
  visit() {
    cy.visit('https://www.demoblaze.com/cart.html');
  }

  removeProduct(productName) {
    cy.xpath(`//td[contains(text(), "${productName}")]/../td/a[contains(text(), "Delete")]`).click();
  }

  placeOrder() {
    cy.get('button').contains('Place Order').click();
  }
}

export default CartPage;
