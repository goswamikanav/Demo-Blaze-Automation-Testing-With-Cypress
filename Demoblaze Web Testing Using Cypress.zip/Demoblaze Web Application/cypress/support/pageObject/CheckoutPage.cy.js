class CheckoutPage {
  enterName(name) {
    cy.get('#name').type(name);
  }

  enterCountry(country) {
    cy.get('#country').type(country);
  }

  enterCity(city) {
    cy.get('#city').type(city);
  }

  enterCreditCard(card) {
    cy.get('#card').type(card);
  }

  enterMonth(month) {
    cy.get('#month').type(month);
  }

  enterYear(year) {
    cy.get('#year').type(year);
  }

  clickPurchase() {
    cy.get('button').contains('Purchase').click();
  }
}

export default CheckoutPage;
