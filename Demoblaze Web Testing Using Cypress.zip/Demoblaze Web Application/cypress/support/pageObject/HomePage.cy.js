class HomePage {
    visit() {
      cy.visit('https://www.demoblaze.com/');
    }
  
    clickHome() {
      cy.get('a').contains('Home').click();
    }
  
    clickCart() {
      cy.get('a').contains('Cart').click();
    }
  
    clickLogin() {
      cy.get('#login2').click();
    }
  }
  
  export default HomePage;
  