class ProductPage {
  selectCategory(category) {
    cy.get('a').contains(category).click();
  }

  selectProduct(productName) {
    cy.get('a').contains(productName).click();
  }

  addToCart() {
    cy.get('a').contains('Add to cart').click();
  }
}

export default ProductPage;
