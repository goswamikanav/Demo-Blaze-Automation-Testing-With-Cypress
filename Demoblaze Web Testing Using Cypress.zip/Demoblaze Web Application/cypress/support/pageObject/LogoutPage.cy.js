class LogoutPage {
  visit() {
    cy.visit('https://www.demoblaze.com/');
  }

  clickLogout() {
    cy.xpath('//a[@id="logout2"]').click();
  }
}

export default LogoutPage;
