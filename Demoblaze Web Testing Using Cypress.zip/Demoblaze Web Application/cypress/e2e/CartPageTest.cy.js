import SignupPage from '../support/pageObject/SignupPage.cy';
import LoginPage from '../support/pageObject/loginPage.cy';
import LogoutPage from '../support/pageObject/LogoutPage.cy';
import HomePage from '../support/pageObject/HomePage.cy';
import ProductPage from '../support/pageObject/ProductPage.cy';
import CartPage from '../support/pageObject/Cartpage.cy';
import CheckoutPage from '../support/pageObject/CheckoutPage.cy';

describe('E-commerce Website Test Automation', () => {
  const signupPage = new SignupPage();
  const loginPage = new LoginPage();
  const logoutPage = new LogoutPage();
  const homePage = new HomePage();
  const productPage = new ProductPage();
  const cartPage = new CartPage();
  const checkoutPage = new CheckoutPage();

  it('should sign up a new user', () => {
    signupPage.visit();
    signupPage.clickSignup();
    signupPage.enterUsername();
    signupPage.enterPassword();
    signupPage.clickSignupButton();
  });

  it('should log in an existing user', () => {
    loginPage.visit();
    loginPage.clickLogin();
    loginPage.enterUsername();
    loginPage.enterPassword();
    loginPage.clickLoginButton();
  });

  it('should navigate to the product category and add a product to the cart', () => {
    homePage.visit();
    productPage.selectCategory('Laptops');
    productPage.selectProduct('Sony vaio i5');
    productPage.addToCart();
  });

  it('should view and modify the cart', () => {
    cartPage.visit();
    cartPage.removeProduct('Sony vaio i5');
  });

  it('should complete the checkout process', () => {
    cartPage.visit();
    cartPage.placeOrder();
    checkoutPage.enterName('Kanav');
    checkoutPage.enterCountry('India');
    checkoutPage.enterCity('Delhi');
    checkoutPage.enterCreditCard('453321111');
    checkoutPage.enterMonth('12');
    checkoutPage.enterYear('2023');
    checkoutPage.clickPurchase();
  });

  it('should log out the user', () => {
    logoutPage.visit();
    logoutPage.clickLogout();
  });
});